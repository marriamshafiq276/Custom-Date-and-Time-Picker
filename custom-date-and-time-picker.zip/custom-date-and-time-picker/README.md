# Custom Date and Time Picker

A browser-based date and time picker built with HTML, CSS, JavaScript, and AngularJS. The interface lets users browse a calendar, choose a date, and set a time using a draggable timeline, increment/decrement controls, or the time input.

## Project structure

```text
custom-date-and-time-picker/
├── README.md
└── custom-date-and-time-picker-using-html-css-and-javascript/
    ├── index.html
    ├── script.js
    └── style.css
```

## Run locally

There is no build step or package installation. The page loads jQuery, AngularJS, and Boxicons from CDNs, so an internet connection is needed for those dependencies.

1. Open a terminal in `custom-date-and-time-picker-using-html-css-and-javascript`.
2. Start a local static server:

   ```sh
   python -m http.server 8000
   ```

3. Open [http://localhost:8000](http://localhost:8000) in a browser.

Alternatively, open that folder in VS Code and run `index.html` with a local static-server extension such as Live Server.

## Features

- Calendar navigation by month.
- Date selection, with past dates disabled by default.
- Time selection with a draggable timeline, five-minute increment/decrement controls, and AM/PM selection.
- A compact layout mode for narrower containers.
- AngularJS bindings in `index.html` for picker title, selected date, custom message, and date/time options.

## Picker options

The `date-picker` element in `custom-date-and-time-picker-using-html-css-and-javascript/index.html` configures the picker:

| Attribute | Current value | Purpose |
| --- | --- | --- |
| `datepicker-title` | `Select Date` | Text displayed as the picker title. |
| `picktime` | `true` | Shows the time picker. |
| `pickdate` | `true` | Enables calendar date selection and month navigation. |
| `pickpast` | `false` | Disables dates before today when false. Set to `true` to allow past dates. |
| `mondayfirst` | `false` | Starts the calendar week on Sunday. Set to `true` to start on Monday. |
| `custom-message` | `You have selected` | Text shown before the selected date. |
| `selecteddate` | `ctrl.selected_date` | AngularJS model for the selected JavaScript `Date`. |
| `updatefn` | `ctrl.updateDate(newdate)` | Callback invoked when the selected date or time changes. |

The controller initializes the selected date to today at 10:00. Its callback currently logs the selected `Date` to the browser console; replace that behavior in `script.js` to connect the picker to an application.

## Notes

The `SAVE` and `CANCEL` controls are presentational only; no click behavior is currently attached to them.
